package service.serviceexception;

public enum ServiceErrorArt {

    DATENBANKERROR,
    VALIDATEERROR,
    ANMELDEERROR,
    USERSERVICE,
    REGISTRATIONERROR,
    IMPORT_EXPORT_ERROR,
    UNKOWNERROR;


}
