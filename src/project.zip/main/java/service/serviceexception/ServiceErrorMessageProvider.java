package service.serviceexception;

public interface ServiceErrorMessageProvider {

    String getServiceErrorMessage();


}
