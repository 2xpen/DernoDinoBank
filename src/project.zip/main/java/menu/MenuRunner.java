package menu;

import menu.startseite.StartseiteManager;

public class MenuRunner {


    public static void run(){
   StartseiteManager startseiteManager = new StartseiteManager();
   startseiteManager.start();
    }


}
