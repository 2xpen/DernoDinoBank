import menu.MenuRunner;

public class Main {

    public static void main(String[] args) {
        // müsste eigentlich eine eigene Klasse geben die quasi die Menuführung  anstößt
       App.start();
    }


}
