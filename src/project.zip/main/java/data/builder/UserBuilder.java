package data.builder;

import data.identifier.UserId;

public class UserBuilder {
    private UserId userId;
    private String username;
    private String password;




}
