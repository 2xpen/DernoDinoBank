package data.anweisungen;

public abstract class AnweisungBase {


    /// der ansatz war anders, dachte ich muss über ein enum dass die art festlegt gehen, aber das geht auich per generic

    protected AnweisungBase() {
    }

}
