package data.identifier;

import java.util.UUID;

public class KontoId extends data.identifier.IdentifierBase {

    public KontoId(String identifier) {
        super(identifier);
    }
    public KontoId() {
        super();
    }

}
