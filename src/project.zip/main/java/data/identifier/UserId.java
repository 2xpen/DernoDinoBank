package data.identifier;

import java.util.UUID;

public class UserId extends IdentifierBase {

    public UserId(String id) {
        super(id);
    }

    public UserId() {
        super();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
