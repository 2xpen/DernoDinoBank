package data.identifier;

public class GevoId extends IdentifierBase {

    public GevoId() {
        super();
    }

    public GevoId(String id) {
        super(id);
    }
}
