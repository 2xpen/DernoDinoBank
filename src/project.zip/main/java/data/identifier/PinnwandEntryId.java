package data.identifier;

public class PinnwandEntryId extends IdentifierBase {

    public PinnwandEntryId() {
        super();
    }

}
