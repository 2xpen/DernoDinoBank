package data.identifier;

import java.util.UUID;

public class PinnwandId extends IdentifierBase{

    protected PinnwandId(String identifier) {
        super(identifier);
    }
}
