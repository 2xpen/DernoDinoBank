package serviceTest;

import data.KontoauszugWrapper;
import data.anweisungen.AbhebungsAnweisung;
import data.anweisungen.AnweisungBase;
import data.anweisungen.UeberweisungsAnweisung;
import data.geschaeftsvorfall.AbhebungGevo;
import data.geschaeftsvorfall.GevoZeile;
import data.geschaeftsvorfall.KontoauszugZeile;
import data.geschaeftsvorfall.UeberweisungGevo;
import data.identifier.KontoId;
import data.identifier.UserId;
import data.user.User;
import data.user.UserName;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import repository.GevoRepository;
import service.GevoService;
import service.KontoService;
import service.UserService;
import service.serviceexception.DatenbankException;
import service.serviceexception.ServiceException;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class GevoServiceTest {

    private GevoRepository gevoRepository;
    private UserService userService;
    private KontoService kontoService;
    private GevoService gevoService;

    @BeforeEach
    public void setUp() {
        gevoRepository = mock(GevoRepository.class);
        userService = mock(UserService.class);
        kontoService = mock(KontoService.class);
        gevoService = new GevoService(gevoRepository, userService, kontoService);
    }

    @Test
    public void testFetchTransaktionsHistorie_Success() throws Exception {
        UserId userId = new UserId("user1");
        KontoId kontoId = new KontoId("konto1");
        List<GevoZeile> gevoZeilen = Arrays.asList(
                new GevoZeile(new java.sql.Timestamp(new Date().getTime()), new KontoId("empfaenger1"), kontoId, "Test Beschreibung", 100.0, null)
        );

        when(kontoService.ermittelKontoIdByUserId(userId)).thenReturn(kontoId);
        when(gevoRepository.fetchGevosOfKonto(kontoId)).thenReturn(gevoZeilen);
        when(userService.ermittleUserByUserId(any())).thenReturn(User.createUser(new UserName("empfaenger@hsw-stud.de")));

        KontoauszugWrapper result = gevoService.fetchTransaktionsHistorie(userId);

        assertNotNull(result);
        assertEquals(1, result.getKontauszugZeile().size());
        verify(gevoRepository, times(1)).fetchGevosOfKonto(kontoId);
    }

    @Test
    public void testFetchTransaktionsHistorie_DatabaseException() throws Exception {
        UserId userId = new UserId("user1");
        when(kontoService.ermittelKontoIdByUserId(userId)).thenThrow(new DatenbankException(DatenbankException.Message.INTERNAL_SERVER_ERROR));

        assertThrows(DatenbankException.class, () -> gevoService.fetchTransaktionsHistorie(userId));
        verify(kontoService, times(1)).ermittelKontoIdByUserId(userId);
    }

    @Test
    public void testDoc_AbhebungGevo() throws Exception {
        AbhebungsAnweisung anweisung = mock(AbhebungsAnweisung.class);
        AbhebungGevo gevo = new AbhebungGevo(anweisung);

        doNothing().when(gevoRepository).createAbhebungsGevo(any(AbhebungGevo.class));

        gevoService.doc(anweisung);

        verify(gevoRepository, times(1)).createAbhebungsGevo(any(AbhebungGevo.class));
    }

    @Test
    public void testDoc_UeberweisungGevo() throws Exception {
        UeberweisungsAnweisung anweisung = mock(UeberweisungsAnweisung.class);
        UeberweisungGevo gevo = new UeberweisungGevo(anweisung);

        doNothing().when(gevoRepository).createUeberweisungsGevo(any(UeberweisungGevo.class));

        gevoService.doc(anweisung);

        verify(gevoRepository, times(1)).createUeberweisungsGevo(any(UeberweisungGevo.class));
    }

    @Test
    public void testDoc_InvalidAnweisung() {
        AnweisungBase anweisung = mock(AnweisungBase.class);

        assertThrows(ServiceException.class, () -> gevoService.doc(anweisung));
    }

    @Test
    public void testDemaskGevoZeile() throws Exception {
        KontoId sender = new KontoId("konto1");
        KontoId empfaenger = new KontoId("konto2");
        UserName senderName = new UserName("Sender");
        UserName empfaengerName = new UserName("Empfaenger");

        List<GevoZeile> gevoZeilen = Arrays.asList(
                new GevoZeile(new java.sql.Timestamp(new Date().getTime()), empfaenger, sender, "Beschreibung", 50.0, null)
        );




        KontoauszugWrapper result = gevoService.demaskGevoZeile(gevoZeilen);

        assertNotNull(result);
        assertEquals(1, result.getKontauszugZeile().size());
        KontoauszugZeile zeile = result.getKontauszugZeile().get(0);
        assertEquals("Sender", zeile.getSender());
        assertEquals("Empfaenger", zeile.getEmpfaenger());
    }
}
